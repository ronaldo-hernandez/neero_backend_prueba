from fastapi import (BackgroundTasks, UploadFile, File, Form, Depends, HTTPException,status)

from fastapi_mail import FastMail, MessageSchema, ConnectionConfig
from dotenv import dotenv_values

from pydantic import BaseModel, EmailStr
from typing import List
from models import User
import jwt


config_credentials = dotenv_values(".env")

conf = ConnectionConfig(
    MAIL_USERNAME = config_credentials["EMAIL"],
    MAIL_PASSWORD = config_credentials["PASSWORD"],
    MAIL_FROM = config_credentials["EMAIL"],
    MAIL_PORT = 587,
    MAIL_SERVER = "smtp.gmail.com",
    MAIL_FROM_NAME="Lectosa REST API",
    MAIL_STARTTLS = True,
    MAIL_SSL_TLS = False,
    USE_CREDENTIALS = True,
    VALIDATE_CERTS = True
)

class EmailSchema(BaseModel):
    email: List[EmailStr]

async def send_email(email: List, instance: User):

    token_data = {
        "id": instance.id, 
        "username" : instance.username
    }
    token = jwt.encode(token_data, config_credentials["SECRET"], algorithm = 'HS256')
    template = f"""
        <!DOCTYPE html>
        <html>
            <head>
            </head>
            <body>
                <div style = "display: flex; align.items: center; justify-content: center; flex-direction:column">
                    <h3> Verificacion de cuenta </h3>
                    <br>
                    <p> Gracias por escoger lactosa, porfavor haz click en el botón de arriba,
                        para verificar tu cuenta. </p>
                    <a style  = "margin-top: 1rem; padding: 1rem; border-radius: 0.5rem;
                    font-size: 1rem; text-decoration: none; background: #0275d8;
                     color: white;" href="http://127.0.0.1:8000/verification/?token={token}"> 
                    Verfifica tu email
                    </a>
                    <p> Porfavor ignora este correo si no eres el que se esta registrando en lectosa y nada pasará, Gracias.</p>
                </div>
            </body>    
        </html>
    """""
    message = MessageSchema(
        subject = "Email de verificacion - Lectosa REST API",
        recipients= email, 
        body = template,
        subtype= "html"
    )
    fm = FastMail(conf)
    await fm.send_message(message=message)